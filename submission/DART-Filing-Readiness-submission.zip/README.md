# DART Filing Readiness

DART 접수 전 감사·검토보고서의 구조를 브라우저에서 점검하는 과제용 웹 애플리케이션입니다. 업무 집중기에 반복되는 수기 체크를 보조하고, 담당자가 확인할 오류와 원문 위치를 함께 보여 줍니다.

- 웹 앱: https://dart-filing-readiness-keunil.tasty-note-8705.chatgpt.site
- 소스: [Keunil/dart-filing-readiness](https://github.com/Keunil/dart-filing-readiness)
- 개발 보고서: [docs/development-report.html](docs/development-report.html)
- 요구사항과 완료 기준: [docs/requirements.md](docs/requirements.md)
- AI 협업과 문제 해결 기록: [docs/ai-collaboration.md](docs/ai-collaboration.md)
- 재사용 출처와 변경: [docs/provenance.md](docs/provenance.md)

작성자: **최근일 · 2026505521** / 삼일회계법인 Assurance 업무 수행 회계사

## 주요 기능

1. 실제 DSD를 선택하거나 가상 회사의 체험 DSD로 시작합니다.
2. 감사인 이름·고유번호(CIK)·주소·대표자 기준을 지정합니다.
3. 문서 코드를 확인하고 해당 보고서의 규칙으로 점검합니다.
4. 오류, 확인 필요, 수동 확인, 통과, 해당 없음을 구분해 표시합니다.
5. 결과를 검색·필터링하고 원문 근거를 확인합니다.
6. 사람이 검토한 항목을 별도로 기록하고 결과를 CSV 또는 XLSX로 내려받습니다.

연차 감사보고서 `00760/00761`과 분·반기 검토보고서 `90020/90220/90320/90420`를 구분합니다. 범위 밖이거나 문서 코드를 확인하지 못한 입력에는 연차 규칙을 임의로 적용하지 않습니다. 연차 점검의 기본 체크리스트 55개와 보조 점검이 있으며, 모든 항목이 자동 판정되는 것은 아닙니다.

## 작동 원리

```text
정적 페이지 로드
  → 사용자 파일 선택 / 브라우저에서 합성 DSD 생성
  → ZIP 안 contents.xml·meta.xml 읽기
  → 보고서 종류·기간·헤더·문단·표 파악
  → 해당 규칙 실행
  → 상태·근거·원문 위치 표시
  → 사람이 검토 / 결과 파일 다운로드
```

웹 서버는 HTML·CSS·JavaScript만 제공합니다. DSD와 결과는 브라우저 메모리에서 처리하며 서버에 업로드하지 않습니다. 콘텐츠 보안 정책의 `connect-src 'none'`으로 분석 중 네트워크 연결을 제한합니다. 새로고침하거나 창을 닫으면 메모리의 파일·결과가 사라집니다. 사용자가 내려받은 파일은 사용자 기기에 남습니다.

## 로컬 실행

추가 패키지 설치 없이 Python의 정적 파일 서버로 실행할 수 있습니다.

```powershell
python -m http.server 8765 --directory public
```

브라우저에서 `http://127.0.0.1:8765`를 엽니다. ES module을 사용하므로 `index.html`을 파일 탐색기에서 직접 여는 방식 대신 HTTP 서버를 사용합니다.

## 개발자 테스트

```powershell
node --test tests/*.test.mjs
```

실제 실행 결과: Node 테스트 11/11 통과, 실패 0, 건너뜀 0. CSV의 수식 접두 문자 보호와 XLSX 문자열 셀 확인을 포함합니다. Agent의 브라우저 시험에서 합성 DSD 점검·CSV/XLSX 다운로드·수동 확인 후 자동 판정 유지·근거 창 닫기 버튼 노출을 확인했습니다. 추가로 실제 오류 DSD 28건의 읽기·점검을 완료하고 연속 두 실행의 판정 일치를 확인했습니다. 담당자 정답 대조와 사용자의 직접 UAT는 미실행입니다.

## 배포

현재 상태: Sites 공개 배포 성공(2026-10-27 KST). 비인증 HTTP 200 및 공개 주소의 합성 샘플 실행을 확인했다. Vercel용 정적 배포 설정도 저장소에 포함했다.

원본 정적 파일은 `public/`에 있으며 Sites는 `node tools/build.mjs`로 복사한 `dist/`를 배포합니다. 백엔드, 데이터베이스, 로그인, 외부 AI API 키가 필요하지 않습니다. Vercel을 사용할 경우 저장소를 가져오고 프레임워크를 Other, 게시 디렉터리를 `public`으로 설정합니다. 저장소의 배포 설정과 실제 공개 접속 확인 결과를 개발 보고서에서 함께 확인합니다.

## 기존 코드와 이번 과제의 범위

기존에 개발하던 DSD 읽기·점검 기능 일부를 활용했습니다. 기술적인 출처와 변경 내역은 docs/provenance.md에 별도로 기록했습니다. 이번 과제에서는 독립 화면, 감사인 프로필 지정, 가상 체험 자료, 결과 탐색과 다운로드, 공개 배포 및 제출 보고서를 구성합니다. 기존 구현까지 이번에 새로 개발했다고 주장하지 않습니다.

## 해석 범위

점검 결과는 제출 전 검토를 돕는 정보입니다. 자동 통과와 담당자의 수동 확인은 별개이며, 점검 결과만으로 보고서의 회계적 적정성이나 DART 접수 가능 여부를 확정하지 않습니다. 실제 업무의 시간·오류 감소 효과는 아직 측정하지 않았습니다.

## 2026-10-28 제출 보고서 보완

- 강의안 연결: [docs/course-alignment.md](docs/course-alignment.md).
- 실제 DSD 28건: [익명 검증 집계](docs/real-dsd-validation.json). 원본은 저장소에 포함하지 않았습니다.
- 신규 오류 예시는 만들지 않았으며 기존 공개 체험만 유지했습니다.
- 고객 파일을 복사하지 않고 기존 엔진으로 읽는 실행기: `tools/validate-private-dsd.mjs`.
- 첨부한 보고서 초안·인계문서와 독립 앱의 범위 차이: [docs/attachment-reconciliation.md](docs/attachment-reconciliation.md).
